
<?php

  session_start(); 
  //$department_name = $_GET['dep_name'];
  //$department_no = $_GET['dep_no'];
  //$section = $_GET['sec'];
  $variable = explode(",", $_GET["variable"]);


  if(!isset($_SESSION['color'])){
    header('location:login.php');
  }

  

   $username1= $_SESSION['username'];
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "ministry";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
    if (mysqli_connect_error())
    {
      die('Connect Error ('. mysqli_connect_errno() .') '
     . mysqli_connect_error());
    }
    else
    {


      $query = "SELECT * FROM accounts WHERE username = '$username1'";
      $run_query = mysqli_query($conn, $query);
      
        $row = mysqli_fetch_assoc($run_query);
   

        $username2=$row["username"];



  





    }




  
   

?>



<!DOCTYPE html>
<html lang="en">
   <head>   
      <meta http-equiv="refresh" content="900;url=logout.php" />

      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Minsitory of Interior</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/logo.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- fonts -->
      <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Sen:wght@400;700;800&display=swap" rel="stylesheet">
      <!-- owl stylesheets --> 
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   </head>
   <body>
      <!-- header section start -->
      <div class="container-fluid">
         <div class="header_section">
            <div class="container">
               <nav class="navbar navbar-light bg-light justify-content-between">

                  <form class="form-inline ">
                     <a class="logo" href="index.html"><img style="text-align: left" src="images/1234-removebg-preview.png"></a>
                     <div class="login_text" style="padding-top: 40px; padding-left: 10px"><h3 style="text-align: center">Kingdom of Bahrian</h3><h1>Ministry of Interior</h1><h6 style="text-align: center; padding-bottom: 1px">Human Resource</h6>></div>
                  </form>
                  <div class="login_menu" style="text-align: right; text-align: top;">
                  <ul>
                        <li><a href="#"><?php echo "Welcome, $username1"  ?></a></li>
                     </ul>
                     <ul>
                     <li><a href="logout.php">Log Out </a></li>

                     </ul>
                  </div>
                  <div id="mySidenav" class="sidenav">
                     
                     <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                     <a href="index.html">Home</a>
                     <a href="service.html">Services</a>
                     <a href="about.html">About MOI</a>
                     <a href="blog.html">E-Services</a>
                     <a href="shop.html">Social Media</a>
                     <a href="contacts.html">Contact us</a>
                  </div>
                  <span class="toggle" onclick="openNav()"><i class="fa fa-bars"></i></span>
               </nav>
            </div>
         </div>
      </div>
      <!-- header section end -->
      <!-- layout main section start -->
      <?php
      $sql = "SELECT * FROM accounts WHERE department_name = '$variable[0]' AND department_no = '$variable[1]' AND section = '$variable[2]'";
      $results = mysqli_query($conn, $sql);
      $row = mysqli_fetch_assoc($results)
      ?>
      <div class="container-fluid">
         <div class="layout_main">
            <!-- banner section start -->

            <!-- banner section end -->
           
          
              <!-- order section start -->
   
              <!-- order section end -->
                       <!-- order section start -->
      <div class="row" style="padding-top:34px">



            <div class="column" style="width:100%">


               <div style="color:white; text-align: center;">

                     <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                     
                     <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                        
                     <b><?php echo $row["username"] ?></b></span><span style="font-size: 12px; font-family: Arial;"><br><?php echo $row["designation"] ?></span>                          
               </div>
  
         
            </div>

<?php 
      $row = mysqli_fetch_assoc($results)

?>
            
            <div class="column" style="width:33.33%; padding-top:50px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b><?php echo $row["username"] ?></b></span><span style="font-size: 12px; font-family: Arial;"><br><?php echo $row["designation"] ?></span>                          
            </div>
  
         
            </div>
            



            <div class="column" style="width:33.33%; padding-top:50px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
  
         
            </div>
            <div class="column" style="width:33.33%; padding-top:50px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
  
         
            </div>



                        
            <div class="column" style="width:25%; padding-top:65px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
  
         
            </div>
            
            <div class="column" style="width:25%; padding-top:65px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
  
         
            </div>
            <div class="column" style="width:25%; padding-top:65px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
  
         
            </div>

            <div class="column" style="width:25%; padding-top:65px;">


               <div style="color:white; text-align: center;">

                  <img src="images/image.png" width="100; text-align:center;" height="100" alt="Your Image">
                  
                  <span style="font-size: 11px; font-family: Arial;"><br>ONLINE<br></span><span style="font-size: 17px;">
                     
                  <b>NAME SURNAME</b></span><span style="font-size: 12px; font-family: Arial;"><br>JOB POSITION</span>                          
            </div>
         
            </div>



      </div>
              <!-- order section end -->
               <!-- order section start -->
        
              <!-- order section end -->
               <!-- order section start -->
          
              <!-- order section end -->
               <!-- order section start -->
           
              <!-- order section end -->
              
             <!-- footer section start -->

             <hr class="new4">

<div style="display:inline;">
   <div style="float: center;">
      
      </div>
      <div style="float: right;">
      <img src="images/2030.png"  
      width="80" 
      height="80">

   </div>
 
</div>
<p class="copyright_text" style="padding-left:100px">Designed & developed by Azher Bakhsh.</p>



      <!-- copyright section end -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>  
      <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
      <script>
         function openNav() {
           document.getElementById("mySidenav").style.width = "100%";
         }
         
         function closeNav() {
           document.getElementById("mySidenav").style.width = "0";
         }
      </script> 
   </body>
</html>